/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxap;
import java.io.IOException;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.text.Text;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
/**
 * FXML Controller class
 *
 * @author بثينة
 */
public class AnimationController implements Initializable {
    TextAnimator textAnimator;
    @FXML
    private Text text;
    @FXML
    private Button nextPage;
    @FXML
    private Text text1;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
    TextOutput textOutput = new TextOutput() {
            @Override
            public void writeText(String textOut) {
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        text.setText(textOut);
                    }
                });
            }
        };
        textAnimator = new TextAnimator("Live it",100, textOutput);
        
    }
    @FXML
    public void start(KeyEvent event) {
    if(event.getCode()==KeyCode.ENTER){
    Thread thread = new Thread(textAnimator);
    thread.start();
    }
    }


    @FXML
    private void on(ActionEvent event) throws Exception {
                     Parent nextPage = FXMLLoader.load(getClass().getResource("javaFXDocument.fxml"));
    Scene next = new Scene(nextPage);
    Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
    stage.setScene(next);
    stage.show();
    }
    }

