/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxap;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

/**
 *
 * @author Alaa
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label1;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void riyadhevent(ActionEvent event) throws IOException {
        Parent nextPage = FXMLLoader.load(getClass().getResource("Riyadh.fxml"));
    Scene next = new Scene(nextPage);
    Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
    stage.setScene(next);
    stage.show();
    }

    @FXML
    private void SelectTaif(ActionEvent event) throws Exception {
         Parent nextPage = FXMLLoader.load(getClass().getResource("Taif.fxml"));
    Scene next = new Scene(nextPage);
    Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
    stage.setScene(next);
    stage.show();
    }

    @FXML
    private void selectMakkah(ActionEvent event) throws Exception {
         Parent nextPage = FXMLLoader.load(getClass().getResource("Makkah.fxml"));
    Scene next = new Scene(nextPage);
    Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
    stage.setScene(next);
    stage.show();
    }

    @FXML
    private void selsctjeddah(ActionEvent event) throws Exception {
         Parent nextPage = FXMLLoader.load(getClass().getResource("jeddah.fxml"));
    Scene next = new Scene(nextPage);
    Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
    stage.setScene(next);
    stage.show();
        
    }

    @FXML
    private void selectMadinah(ActionEvent event) throws Exception {
         Parent nextPage = FXMLLoader.load(getClass().getResource("Madinah2.fxml"));
    Scene next = new Scene(nextPage);
    Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
    stage.setScene(next);
    stage.show();
        
    }

    @FXML
    private void Home(ActionEvent event) throws Exception {
         Parent nextPage = FXMLLoader.load(getClass().getResource("javaFXDocument.fxml"));
    Scene next = new Scene(nextPage);
    Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
    stage.setScene(next);
    stage.show();
    }

    @FXML
    private void add(ActionEvent event) throws Exception {
         Parent nextPage = FXMLLoader.load(getClass().getResource("adding.fxml"));
    Scene next = new Scene(nextPage);
    Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
    stage.setScene(next);
    stage.show();
    }
    
    
    
}
