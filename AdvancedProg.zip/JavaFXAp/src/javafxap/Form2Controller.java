/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxap;

import java.net.URL;
import java.time.LocalDate;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListView;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 * FXML Controller class
 *
 * @author lofy1
 */
public class Form2Controller implements Initializable {

    @FXML
    private Button back;
       
        @FXML
        TextField date;
        @FXML
        TextField numberofpeople;
        @FXML
        TextField time;
        @FXML
        TextField email;
        @FXML
        TextField mobile;
        @FXML
        TextArea note;
        
        
        
        @FXML
        ListView <String> lvdate;
        @FXML
        ListView <String> lvnumberofpeople ;
        @FXML
        ListView <String> lvtime ;
        @FXML
        ListView <String> lvmobile ;
        @FXML
        ListView <String> lvemail ;
        @FXML
        ListView <String> lvnote ;
    @FXML
    private Button deletebutton;
    
        
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        HibernateUtil.getSessionFactory().openSession();
List<forminfo> PL = null;
String queryStr = "from forminfo";
Query query = session.createQuery(queryStr);
PL = query.list();
session.close();
System.out.println("patient list size: "+PL.size());
for(forminfo p: PL)
{
lvdate.getItems().add(p.getDate());
lvnumberofpeople.getItems().add(p.getNumberofpeople());
lvtime.getItems().add(p.getTime());
lvemail.getItems().add(p.getEmail());
lvmobile.getItems().add(p.getMobile());
lvnote.getItems().add(p.getNote());
}
        // TODO
    }    

    @FXML
    private void back2(ActionEvent event) throws Exception {
         Parent nextPage = FXMLLoader.load(getClass().getResource("Madinah2.fxml"));
    Scene next = new Scene(nextPage);
    Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
    stage.setScene(next);
    stage.show();
    }
  @FXML
    private void reverse(MouseEvent event) {
        showInformation(date.getText(),numberofpeople.getText(),time.getText(),mobile.getText(),email.getText(),note.getText());
        forminfo p = new forminfo();
              p.setEmail(email.getText());
              p.setMobile(mobile.getText());
              p.setNote(note.getText());
              p.setNumberofpeople(numberofpeople.getText());
              p.setDate(date.getText());
              
              Session session1 = HibernateUtil.getSessionFactory().openSession();
              session1 = HibernateUtil.getSessionFactory().openSession();
              Transaction tx = session1.beginTransaction();
              
              session1.save(p);
              tx.commit();
              session1.close();
              
    }
    
    public void showInformation(String date,String numberofpeople,String time,String mobile,String email,String note){
         
         lvdate.getItems().add(date);
         lvnumberofpeople.getItems().add(numberofpeople);
         lvtime.getItems().add(time);
         lvmobile.getItems().add(mobile);
         lvemail.getItems().add(email);
         lvnote.getItems().add(note);
     }

    @FXML
    private void delete(ActionEvent event) {
        forminfo p = new forminfo();
        if(lvmobile.getItems().contains(this.mobile.getText())){
             int index = lvmobile.getItems().indexOf(this.mobile.getText());
             
              p.setEmail(lvemail.getItems().get(index));
              p.setMobile(lvmobile.getItems().get(index));
              p.setNote(lvnote.getItems().get(index));
              p.setNumberofpeople(lvnumberofpeople.getItems().get(index));
              p.setDate(lvdate.getItems().get(index));
              String s=lvmobile.getItems().get(index);
         lvdate.getItems().remove(index);
         lvnumberofpeople.getItems().remove(index);
         lvtime.getItems().remove(index);
         lvmobile.getItems().remove(index);
         lvemail.getItems().remove(index);
         lvnote.getItems().remove(index);
        
              Session session = HibernateUtil.getSessionFactory().openSession();
              session = HibernateUtil.getSessionFactory().openSession();
              Transaction tx2 = null;
              tx2 = session.beginTransaction();
              session.delete(p);
              tx2.commit();
              session.close();}
    }

}




