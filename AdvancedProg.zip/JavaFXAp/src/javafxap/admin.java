package javafxap;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table (name="admin")
public class admin implements java.io.Serializable{
    @Id
   @Column(name="Nameofevent")
   private String Nameofevent;
   @Column(name="city")
   private String city;
   @Column(name="date")
   private String date;
   @Column(name="name")
   private String name;
   @Column(name="description")
   private String description;
    public admin() {
    }

    public void setNameofevent(String Nameofevent) {
        this.Nameofevent = Nameofevent;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getNameofevent() {
        return Nameofevent;
    }

    public String getCity() {
        return city;
    }

    public String getDate() {
        return date;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }
    
    
}
