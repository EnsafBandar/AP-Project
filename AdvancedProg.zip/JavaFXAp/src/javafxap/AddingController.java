/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxap;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import java.time.LocalDate;
import java.io.Serializable; 
import java.util.List; 
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import org.hibernate.*;
/**
 * FXML Controller class
 *
 * @author بثينة
 */
public class AddingController implements Initializable {

    @FXML
    private ComboBox<String> c;
    @FXML
    private ListView<String> eventName;
    @FXML
    private TextField date;
    @FXML
    private TextField hisName;
    private ListView<String> d;
    @FXML
    private TextField name;
    @FXML
    private TextArea description;
    @FXML
    private ListView<String> city1;
    @FXML
    private ListView<String> datelistview;
    @FXML
    private ListView<String> hisNamelistview;
    @FXML
    private ListView<String> descriptionlistview;
    @FXML
    private Button v;

    public AddingController() {
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    ObservableList<String>city=FXCollections.observableArrayList("Makah","Jeddah","AL-riyadh","AL-Taif","AL-Madinah");
    c.setItems(city);
    c.setValue("Makkah");
    admin a=new admin();
    Session session=HibernateUtil.getSessionFactory().openSession();
    List<admin>n=null;
    String queryStr = "from admin";
    Query query = session.createQuery(queryStr);
    n=query.list();
    session.close();
    System.out.println(" list size: "+n.size());
    for(admin s: n) {
    eventName.getItems().add(s.getNameofevent());
    city1.getItems().add(s.getCity());
    datelistview.getItems().add(s.getDate());
    hisNamelistview.getItems().add(s.getName());
    descriptionlistview.getItems().add(s.getDescription());}
    
    }
    @FXML
    public void add(ActionEvent event) {
    admin a=new admin();
    eventName.getItems().add(name.getText());
    city1.getItems().add(c.getValue());
    datelistview.getItems().add(date.getText());
    hisNamelistview.getItems().add(hisName.getText());
    descriptionlistview.getItems().add(description.getText());  
    a.setNameofevent(name.getText()); 
    a.setCity(c.getValue());
    a.setDate(date.getText()); 
    a.setName(hisName.getText());
    a.setDescription(description.getText());
    Session session = HibernateUtil.getSessionFactory().openSession(); 
    session = HibernateUtil.getSessionFactory().openSession();
    Transaction tx = session.beginTransaction();
    String a1 = (String) session.save(a);
    tx.commit(); 
    session.close();
    }
    @FXML
    public void delete(ActionEvent event) {
    admin a=new admin();
    if(eventName.getItems().contains(name.getText())){
    int index= eventName.getItems().indexOf(name.getText());
    a.setNameofevent(eventName.getItems().get(index));
    a.setCity(city1.getItems().get(index));
    a.setDate(datelistview.getItems().get(index));
    a.setName(hisNamelistview.getItems().get(index));
    a.setDescription(descriptionlistview.getItems().get(index));
    String s=eventName.getItems().get(index);
    eventName.getItems().remove(index);
    city1.getItems().remove(index);
    datelistview.getItems().remove(index);
    hisNamelistview.getItems().remove(index);
    descriptionlistview.getItems().remove(index);
    Session session = HibernateUtil.getSessionFactory().openSession();
    Transaction tx3 = null;
    tx3 = session.beginTransaction();
    session.delete(a);
    tx3.commit();
    session.close();
    }
    }
    @FXML
    public void clear(ActionEvent event) {
    name.clear();
    date.clear();
    hisName.clear();
    description.clear();
    }

    public void name(ActionEvent event) {
    }

    @FXML
    private void city(ActionEvent event) {
    }


    @FXML
    private void hisName(ActionEvent event) {
    }

    @FXML
    private void date1(ActionEvent event) {
    }

    @FXML
    private void homePage(ActionEvent event) throws Exception {
         Parent nextPage = FXMLLoader.load(getClass().getResource("javaFXDocument.fxml"));
    Scene next = new Scene(nextPage);
    Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
    stage.setScene(next);
    stage.show();
    }
    @FXML
    private void shopping(ActionEvent event) throws Exception {
        Parent nextPage = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
    Scene next = new Scene(nextPage);
    Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
    stage.setScene(next);
    stage.show();
    }

    @FXML
    private void back(ActionEvent event) throws Exception {
        Parent nextPage = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
    Scene next = new Scene(nextPage);
    Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
    stage.setScene(next);
    stage.show();
    }
}
