/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxap;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author user
 */
public class StartController implements Initializable {

    @FXML
    private Hyperlink forgot;
    @FXML
    private Button login;
    @FXML
    private Label or;
    @FXML
    private Button facebok;
    @FXML
    private TextField username;
    @FXML
    private PasswordField name;
    @FXML
    private Button gogle;
    @FXML
    private Button signup;
    @FXML
    private Label lblmsg;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }
   

    @FXML
    private void login(ActionEvent event) throws Exception {
        if(username.getText().isEmpty() && name.getText().isEmpty()){
                lblmsg.setText("Enter username and password");
            }
            else if(name.getText().length() !=10){
            lblmsg.setText("The length of password must be 10 letters");
            }
            else {
        Parent nextPage = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
    Scene next = new Scene(nextPage);
    Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
    stage.setScene(next);
    stage.show();
    }
    }

    @FXML
    private void changesc(ActionEvent event) throws Exception {
         Parent nextPage = FXMLLoader.load(getClass().getResource("signup.fxml"));
    Scene next = new Scene(nextPage);
    Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
    stage.setScene(next);
    stage.show();
    }
    
}
