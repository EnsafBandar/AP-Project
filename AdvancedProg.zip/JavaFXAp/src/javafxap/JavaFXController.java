 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxap;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author user
 */
public class JavaFXController implements Initializable {

    @FXML
    private Button image1;
    @FXML
    private Button emage2;
    @FXML
    private Button image3;
    @FXML
    private Button image4;
    @FXML
    private Button image5;
    @FXML
    private Button image6;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void w(ActionEvent event) throws Exception {
                                                                            
Parent nextPage = FXMLLoader.load(getClass().getResource("text1.fxml"));
         Scene next = new Scene(nextPage);
    Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
    stage.setScene(next);
    stage.show(); 
    }

    @FXML
    private void amazon(ActionEvent event) throws Exception {
                                                                            
Parent nextPage = FXMLLoader.load(getClass().getResource("text2.fxml"));
         Scene next = new Scene(nextPage);
    Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
    stage.setScene(next);
    stage.show(); 
    }

    @FXML
    private void R(ActionEvent event) throws Exception {
                                                                            
Parent nextPage = FXMLLoader.load(getClass().getResource("text3.fxml"));
         Scene next = new Scene(nextPage);
    Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
    stage.setScene(next);
    stage.show(); 
    }

    @FXML
    private void event4(ActionEvent event) throws Exception {
                                                                            
Parent nextPage = FXMLLoader.load(getClass().getResource("text4.fxml"));
         Scene next = new Scene(nextPage);
    Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
    stage.setScene(next);
    stage.show(); 
    }

    @FXML
    private void event5(ActionEvent event) throws Exception {
                                                                            
Parent nextPage = FXMLLoader.load(getClass().getResource("text5.fxml"));
         Scene next = new Scene(nextPage);
    Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
    stage.setScene(next);
    stage.show(); 
    }

    @FXML
    private void event6(ActionEvent event) throws IOException {
                                                                            
Parent nextPage = FXMLLoader.load(getClass().getResource("text6.fxml"));
         Scene next = new Scene(nextPage);
    Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
    stage.setScene(next);
    stage.show(); 
    }

      

    @FXML
    private void User(ActionEvent event) throws Exception {
                     Parent nextPage = FXMLLoader.load(getClass().getResource("Start.fxml"));
    Scene next = new Scene(nextPage);
    Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
    stage.setScene(next);
    stage.show();
    }
    }
    

 
    
    

