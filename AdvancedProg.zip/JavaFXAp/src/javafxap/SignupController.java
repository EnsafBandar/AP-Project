/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxap;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author ensaf
 */
public class SignupController implements Initializable {

    @FXML
    private RadioButton femalebtn;
    @FXML
    private ToggleGroup Gender;
    @FXML
    private RadioButton malebtn;
    @FXML
    private Button create;
    @FXML
    private Label signup;
    @FXML
    private TextField fullname;
    @FXML
    private TextField email;
    @FXML
    private TextField mobile;
    @FXML
    private TextField pass;
    @FXML
    private Label gender;
    @FXML
    private Label date;
    @FXML
    private DatePicker date2;
    @FXML
    private Label lblmsg2;
    @FXML
    private Label lbl1;
    @FXML
    private Label lbl2;
    @FXML
    private Label lbl3;
    
    @FXML
    private void changetwo(ActionEvent event) throws Exception {
        Parent nextPage = FXMLLoader.load(getClass().getResource("Start.fxml"));
    Scene next = new Scene(nextPage);
    Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
    stage.setScene(next);
    stage.show();
    }

    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void Create(ActionEvent event) throws Exception {
        if(fullname.getText().isEmpty() && pass.getText().isEmpty()&& mobile.getText().isEmpty()&& email.getText().isEmpty()){
                lblmsg2.setText("Please fill your information !!");
            }
            else if(mobile.getText().length() !=10){
            lblmsg2.setText("The length of Mobile number must be 10 digits");
            }
           else{
                Parent nextPage = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
    Scene next = new Scene(nextPage);
    Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
    stage.setScene(next);
    stage.show();
         
    }
    }

    @FXML
    private void save(ActionEvent event) { //property event
           lbl2.textProperty().bind(fullname.textProperty());
        
    }
    
}
